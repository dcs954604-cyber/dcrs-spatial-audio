# DCRS Spatial Audio — prototype 0.1

## What this build does
- Runs in a modern Android browser.
- Uses the front camera and MediaPipe Face Landmarker for approximate face/head yaw.
- Plays a music file selected by the user on the phone.
- Uses the browser Web Audio API `PannerNode` with HRTF panning to create a basic 3D/binaural-style effect.
- Keeps camera processing in the browser; selected music is not uploaded.

## Test on POCO F1 (Android 10)
1. Extract this ZIP.
2. Host the folder on an HTTPS static host (for example, GitHub Pages or another HTTPS host), or run it on a computer and open it through an HTTPS tunnel.
3. Open the HTTPS page in Chrome on the POCO F1.
4. Connect the Apple 3.5 mm EarPods.
5. Choose an audio file, tap **Enable spatial audio**, and allow audio playback.
6. Tap **Start camera tracking** and allow camera permission.
7. Face the phone, tap **Set centre**, then slowly turn your head left and right.

Camera access generally does not work from a plain `file://` page. HTTPS or localhost is required. First load needs internet access for the MediaPipe model/CDN.

## Important limitations
- This is an experimental prototype, not Apple's proprietary Spatial Audio or AirPods head tracking.
- The yaw estimate is approximate and can be affected by camera angle, lighting, and face position.
- A website cannot capture and spatialize arbitrary audio playing in another app (Spotify, YouTube Music, etc.). This prototype processes only the audio file selected inside the page.
- HRTF results depend on the browser and headphones. Wired EarPods are supported as ordinary stereo headphones.
- Keep the phone stable and in front of your face for reliable tracking.

## Android app phase (planned)
For the follow-up native Android app, use Kotlin + CameraX + MediaPipe Tasks Vision + Android audio APIs. Android Audio Playback Capture can capture eligible playback from other apps only when the source app permits it and Android requirements are met; it is not universal. The more reliable first native version should play local/imported music inside DCRS and apply binaural processing.
